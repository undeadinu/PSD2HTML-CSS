require 'compass/import-once/activate'
# Require any additional compass plugins here.

# CSS 파일 기본 인코딩(Default Encoding) 설정
# Windows에서 한글, 일어, 중국어 등 SCSS 파일을 CSS로 컴파일 시 문자 인코딩 에러가 생길 경우
# 아래 코드를 설정하여 기본 인코딩을 UTF-8로 설정하면 문제가 해결됨.
# https://gist.githubusercontent.com/yamoo9/f2c3c86f33a8e02c166a/raw/18dd59d1cb10d26066fd56f91a6dc571ba843882/config.rb
Encoding.default_external = "utf-8"

# Set this to the root of your project when deployed:
http_path = "/"
css_dir = "css"
sass_dir = "sass"
images_dir = "images"
javascripts_dir = "js"
fonts_dir = "fonts"

output_style = :expanded

relative_assets = true

line_comments = false
color_output = false

preferred_syntax = :sass