var gulp        = require('gulp'),
	concatCss   = require('gulp-concat-css'),
	cssbeautify = require('gulp-cssbeautify');


gulp.task('default', ['css', 'watch']);
gulp.task('watch', function() {
	gulp.watch(['www/css/style.css', '!www/css/bundle.css'], ['css']);
});

gulp.task('css', function() {
	return gulp
		.src([
			'www/css/style.css', '!www/css/bundle.css'
		])
		.pipe( concatCss("css/bundle.css") )
		.pipe(cssbeautify({
			indent        : '	',
			// openbrace     : 'separate-line', // end-of-line, separate-line
			// autosemicolon : true
		}))
		.pipe(gulp.dest('www/'));
});

